package com.shahriar.animeturntable;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

public class SpriteTurntableView extends View {
    private static final int FRAME_COUNT = 60;
    private static final float DEGREES_PER_FRAME = 360f / FRAME_COUNT;

    private final int[] frameIds = new int[FRAME_COUNT];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final ScaleGestureDetector scaleDetector;
    private final LruCache<Integer, Bitmap> bitmapCache;

    private float angleDeg = 0f;
    private float zoom = 1f;
    private float lastX = 0f;
    private float fitScale = 1f;

    public SpriteTurntableView(Context context) {
        this(context, null);
    }

    public SpriteTurntableView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(247, 247, 247));

        for (int i = 0; i < FRAME_COUNT; i++) {
            String name = String.format("frame_%02d", i);
            frameIds[i] = getResources().getIdentifier(name, "drawable", context.getPackageName());
        }

        final int cacheSizeKb = 32 * 1024;
        bitmapCache = new LruCache<Integer, Bitmap>(cacheSizeKb) {
            @Override
            protected int sizeOf(Integer key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };

        scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        zoom *= detector.getScaleFactor();
                        zoom = Math.max(0.85f, Math.min(4.0f, zoom));
                        invalidate();
                        return true;
                    }
                });
    }

    private Bitmap getFrame(int index) {
        index = (index % FRAME_COUNT + FRAME_COUNT) % FRAME_COUNT;
        Bitmap cached = bitmapCache.get(index);
        if (cached != null && !cached.isRecycled()) {
            return cached;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap decoded = BitmapFactory.decodeResource(getResources(), frameIds[index], options);
        if (decoded != null) {
            bitmapCache.put(index, decoded);
        }
        return decoded;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Bitmap first = getFrame(0);
        if (first != null) {
            float sx = (float) w / first.getWidth();
            float sy = (float) h / first.getHeight();
            fitScale = Math.max(sx, sy) * 0.98f;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.rgb(247, 247, 247));

        float normalized = normalizeAngle(angleDeg);
        float exactFrame = normalized / DEGREES_PER_FRAME;
        int lower = ((int) Math.floor(exactFrame)) % FRAME_COUNT;
        int upper = (lower + 1) % FRAME_COUNT;
        float mix = exactFrame - (float) Math.floor(exactFrame);

        Bitmap first = getFrame(lower);
        Bitmap second = getFrame(upper);

        if (first != null) {
            drawFrame(canvas, first, 1f - mix);
        }
        if (second != null && mix > 0.001f) {
            drawFrame(canvas, second, mix);
        }
    }

    private void drawFrame(Canvas canvas, Bitmap bitmap, float alpha) {
        float scale = fitScale * zoom;
        float width = bitmap.getWidth() * scale;
        float height = bitmap.getHeight() * scale;

        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        matrix.postTranslate((getWidth() - width) / 2f, (getHeight() - height) / 2f);

        paint.setAlpha(Math.max(0, Math.min(255, (int) (255f * alpha))));
        canvas.drawBitmap(bitmap, matrix, paint);
        paint.setAlpha(255);
    }

    private float normalizeAngle(float value) {
        float angle = value % 360f;
        return angle < 0f ? angle + 360f : angle;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!scaleDetector.isInProgress() && event.getPointerCount() == 1) {
                    float x = event.getX();
                    float dx = x - lastX;
                    float sensitivity = 220f / Math.max(1f, getWidth());
                    angleDeg += dx * sensitivity;
                    lastX = x;
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                int remaining = event.getActionIndex() == 0 ? 1 : 0;
                if (remaining < event.getPointerCount()) {
                    lastX = event.getX(remaining);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                performClick();
                return true;

            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
