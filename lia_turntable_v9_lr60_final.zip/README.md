# Lia LR60

Fullscreen Android turntable.

- 60 horizontal rotation frames (6° spacing)
- One-finger left/right rotation only
- Two-finger pinch zoom
- No vertical tilt
- Neighbor-frame cross-fade for smoother movement
