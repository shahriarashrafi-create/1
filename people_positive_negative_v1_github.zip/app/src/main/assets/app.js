(() => {
  const STORAGE_KEY = 'peopleScore.entries.v1';
  const LAST_PERSON_KEY = 'peopleScore.lastPerson.v1';
  let entries = loadEntries();
  let selectedType = 'positive';
  let currentPage = 'home';
  let openedEntryId = null;
  let editType = 'positive';
  let toastTimer = null;

  const $ = (id) => document.getElementById(id);
  const homePage = $('homePage');
  const profilePage = $('profilePage');
  const personInput = $('personInput');
  const titleInput = $('titleInput');
  const descriptionInput = $('descriptionInput');
  const scoreInput = $('scoreInput');
  const scoreBadge = $('scoreBadge');
  const saveEntry = $('saveEntry');
  const positiveType = $('positiveType');
  const negativeType = $('negativeType');
  const detailModal = $('detailModal');
  const deleteModal = $('deleteModal');
  const detailView = $('detailView');
  const editView = $('editView');

  function loadEntries() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(raw) ? raw.filter(Boolean) : [];
    } catch (_) { return []; }
  }

  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    renderPeopleSuggestions();
  }

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  function clampScore(value) {
    const n = Number.parseInt(value, 10);
    if (!Number.isFinite(n)) return 1;
    return Math.max(1, Math.min(100, n));
  }

  function people() {
    const map = new Map();
    entries.forEach(e => {
      const name = String(e.person || '').trim();
      if (name && !map.has(name.toLocaleLowerCase('fa'))) map.set(name.toLocaleLowerCase('fa'), name);
    });
    return [...map.values()].sort((a,b) => a.localeCompare(b, 'fa'));
  }

  function renderPeopleSuggestions() {
    $('peopleSuggestions').innerHTML = people().map(name => `<option value="${escapeHtml(name)}"></option>`).join('');
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }

  function setType(type) {
    selectedType = type === 'negative' ? 'negative' : 'positive';
    positiveType.classList.toggle('active', selectedType === 'positive');
    negativeType.classList.toggle('active', selectedType === 'negative');
    scoreBadge.className = `score-badge ${selectedType}`;
    saveEntry.className = `save-btn ${selectedType}`;
    saveEntry.querySelector('span').textContent = selectedType === 'positive' ? '+' : '−';
    saveEntry.querySelector('b').textContent = selectedType === 'positive' ? 'ثبت نکته مثبت' : 'ثبت نکته منفی';
    updateScoreUI();
  }

  function updateScoreUI() {
    const score = clampScore(scoreInput.value);
    scoreInput.value = score;
    scoreBadge.textContent = `${selectedType === 'positive' ? '+' : '−'}${score}`;
    document.querySelectorAll('.quick-scores button').forEach(btn => btn.classList.toggle('active', Number(btn.dataset.score) === score));
  }

  function showToast(text) {
    const toast = $('toast');
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
  }

  function saveNewEntry() {
    const person = personInput.value.trim();
    const title = titleInput.value.trim();
    const description = descriptionInput.value.trim();
    const score = clampScore(scoreInput.value);
    if (!person) { showToast('نام فرد را وارد کن'); personInput.focus(); return; }
    if (!title) { showToast('عنوان را وارد کن'); titleInput.focus(); return; }

    entries.unshift({
      id: uid(),
      person,
      type: selectedType,
      title,
      description,
      score,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    persist();
    localStorage.setItem(LAST_PERSON_KEY, person);
    titleInput.value = '';
    descriptionInput.value = '';
    scoreInput.value = 5;
    updateScoreUI();
    showToast(selectedType === 'positive' ? 'نکته مثبت ثبت شد' : 'نکته منفی ثبت شد');
  }

  function showPage(page, preferredPerson) {
    currentPage = page === 'profile' ? 'profile' : 'home';
    homePage.classList.toggle('active', currentPage === 'home');
    profilePage.classList.toggle('active', currentPage === 'profile');
    $('pageTitle').textContent = currentPage === 'home' ? 'ثبت ویژگی' : 'پروفایل';
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.page === currentPage));
    if (currentPage === 'profile') renderProfile(preferredPerson || personInput.value.trim());
    window.scrollTo({top:0, behavior:'auto'});
  }

  function renderProfile(preferredPerson) {
    const names = people();
    const select = $('profilePersonSelect');
    if (!names.length) {
      select.innerHTML = '<option value="">بدون فرد</option>';
      select.disabled = true;
      $('profileEmpty').classList.remove('hidden');
      $('profileContent').classList.add('hidden');
      return;
    }
    select.disabled = false;
    const previous = preferredPerson || select.value || localStorage.getItem(LAST_PERSON_KEY) || names[0];
    select.innerHTML = names.map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('');
    const chosen = names.includes(previous) ? previous : names[0];
    select.value = chosen;
    $('profileEmpty').classList.add('hidden');
    $('profileContent').classList.remove('hidden');
    renderPerson(chosen);
  }

  function renderPerson(person) {
    const personEntries = entries.filter(e => e.person === person);
    const positives = personEntries.filter(e => e.type === 'positive');
    const negatives = personEntries.filter(e => e.type === 'negative');
    const posTotal = positives.reduce((sum,e) => sum + clampScore(e.score), 0);
    const negTotal = negatives.reduce((sum,e) => sum + clampScore(e.score), 0);
    const net = posTotal - negTotal;

    $('selectedPersonName').textContent = person;
    $('positiveCount').textContent = positives.length;
    $('negativeCount').textContent = negatives.length;
    $('positiveTotal').textContent = `+${posTotal}`;
    $('negativeTotal').textContent = `−${negTotal}`;
    $('netScore').textContent = `${net > 0 ? '+' : net < 0 ? '−' : ''}${Math.abs(net)}`;
    $('netPill').className = `net-pill ${net > 0 ? 'positive' : net < 0 ? 'negative' : ''}`;

    renderColumn($('positiveList'), positives, '+');
    renderColumn($('negativeList'), negatives, '−');
    localStorage.setItem(LAST_PERSON_KEY, person);
  }

  function renderColumn(container, list, sign) {
    if (!list.length) {
      container.innerHTML = '<div class="empty-row">موردی ثبت نشده</div>';
      return;
    }
    container.innerHTML = list.map(e => `
      <button type="button" class="entry-row" data-entry-id="${escapeHtml(e.id)}">
        <span class="row-title">${escapeHtml(e.title)}</span>
        <span class="row-score">${sign}${clampScore(e.score)}</span>
      </button>`).join('');
  }

  function formatDate(iso) {
    try {
      return new Intl.DateTimeFormat('fa-IR', {dateStyle:'medium', timeStyle:'short'}).format(new Date(iso));
    } catch (_) { return ''; }
  }

  function openEntry(id) {
    const entry = entries.find(e => e.id === id);
    if (!entry) return;
    openedEntryId = id;
    $('detailKind').textContent = entry.type === 'positive' ? 'نکته مثبت' : 'نکته منفی';
    $('detailKind').style.color = entry.type === 'positive' ? 'var(--positive)' : 'var(--negative)';
    $('detailPerson').textContent = entry.person;
    $('detailTitle').textContent = entry.title;
    $('detailScore').textContent = `${entry.type === 'positive' ? '+' : '−'}${clampScore(entry.score)}`;
    $('detailScore').style.color = entry.type === 'positive' ? 'var(--positive)' : 'var(--negative)';
    $('detailDescription').textContent = entry.description || 'توضیحی ثبت نشده است.';
    $('detailDate').textContent = formatDate(entry.createdAt);
    detailView.classList.remove('hidden');
    editView.classList.add('hidden');
    detailModal.classList.remove('hidden');
    detailModal.setAttribute('aria-hidden','false');
  }

  function closeDetail() {
    detailModal.classList.add('hidden');
    detailModal.setAttribute('aria-hidden','true');
    openedEntryId = null;
  }

  function beginEdit() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) return;
    editType = entry.type;
    $('editTitle').value = entry.title;
    $('editScore').value = clampScore(entry.score);
    $('editDescription').value = entry.description || '';
    syncEditTypeButtons();
    detailView.classList.add('hidden');
    editView.classList.remove('hidden');
  }

  function syncEditTypeButtons() {
    document.querySelectorAll('[data-edit-type]').forEach(btn => btn.classList.toggle('active', btn.dataset.editType === editType));
  }

  function saveEdit() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) return;
    const title = $('editTitle').value.trim();
    if (!title) { showToast('عنوان را وارد کن'); return; }
    entry.title = title;
    entry.score = clampScore($('editScore').value);
    entry.description = $('editDescription').value.trim();
    entry.type = editType;
    entry.updatedAt = new Date().toISOString();
    persist();
    closeDetail();
    renderProfile(entry.person);
    showToast('تغییرات ذخیره شد');
  }

  function askDelete() {
    if (!openedEntryId) return;
    deleteModal.classList.remove('hidden');
    deleteModal.setAttribute('aria-hidden','false');
  }

  function closeDelete() {
    deleteModal.classList.add('hidden');
    deleteModal.setAttribute('aria-hidden','true');
  }

  function confirmDelete() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) { closeDelete(); return; }
    const person = entry.person;
    entries = entries.filter(e => e.id !== openedEntryId);
    persist();
    closeDelete();
    closeDetail();
    renderProfile(person);
    showToast('مورد حذف شد');
  }

  positiveType.addEventListener('click', () => setType('positive'));
  negativeType.addEventListener('click', () => setType('negative'));
  $('scoreMinus').addEventListener('click', () => { scoreInput.value = clampScore(Number(scoreInput.value) - 1); updateScoreUI(); });
  $('scorePlus').addEventListener('click', () => { scoreInput.value = clampScore(Number(scoreInput.value) + 1); updateScoreUI(); });
  scoreInput.addEventListener('input', updateScoreUI);
  document.querySelectorAll('.quick-scores button').forEach(btn => btn.addEventListener('click', () => { scoreInput.value = btn.dataset.score; updateScoreUI(); }));
  $('clearPerson').addEventListener('click', () => { personInput.value = ''; personInput.focus(); });
  saveEntry.addEventListener('click', saveNewEntry);
  document.querySelectorAll('.nav-btn').forEach(btn => btn.addEventListener('click', () => showPage(btn.dataset.page)));
  $('emptyGoHome').addEventListener('click', () => showPage('home'));
  $('profilePersonSelect').addEventListener('change', e => renderPerson(e.target.value));
  $('profileContent').addEventListener('click', e => {
    const row = e.target.closest('[data-entry-id]');
    if (row) openEntry(row.dataset.entryId);
  });
  document.querySelectorAll('[data-close="detail"]').forEach(el => el.addEventListener('click', closeDetail));
  document.querySelectorAll('[data-close="delete"]').forEach(el => el.addEventListener('click', closeDelete));
  $('editEntryBtn').addEventListener('click', beginEdit);
  $('deleteEntryBtn').addEventListener('click', askDelete);
  $('saveEditBtn').addEventListener('click', saveEdit);
  $('cancelEditBtn').addEventListener('click', () => { detailView.classList.remove('hidden'); editView.classList.add('hidden'); });
  $('confirmDeleteBtn').addEventListener('click', confirmDelete);
  document.querySelectorAll('[data-edit-type]').forEach(btn => btn.addEventListener('click', () => { editType = btn.dataset.editType; syncEditTypeButtons(); }));

  window.handleAndroidBack = () => {
    if (!deleteModal.classList.contains('hidden')) { closeDelete(); return 'handled'; }
    if (!detailModal.classList.contains('hidden')) {
      if (!editView.classList.contains('hidden')) { detailView.classList.remove('hidden'); editView.classList.add('hidden'); return 'handled'; }
      closeDetail(); return 'handled';
    }
    if (currentPage === 'profile') { showPage('home'); return 'handled'; }
    return 'exit';
  };

  const lastPerson = localStorage.getItem(LAST_PERSON_KEY);
  if (lastPerson) personInput.value = lastPerson;
  renderPeopleSuggestions();
  setType('positive');
  updateScoreUI();
})();
