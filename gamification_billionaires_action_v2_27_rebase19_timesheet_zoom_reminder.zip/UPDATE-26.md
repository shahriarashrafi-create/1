# Update 26 — TimeSheet v7 integrated

Base: v2.25 rebase-on-v19.

- Added a new TimeSheet page between Vault and Achievements.
- Ported TimeSheet v7 core behavior into the gamification UI: 7-day weekly grid, 07:00-24:00, ±10 weeks, recurring weekly programs, create/edit/delete, done/missed/planned states, weekly overview, planned/done/missed/free hour stats, and Persian calendar dates.
- Rebuilt all TimeSheet styling in the gamification neon/navy/gold visual language, including the existing light theme.
- TimeSheet state is included in gamification save/export/import data.
