package com.shahriar.gamification;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class TimesheetReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "timesheet_reminders";
    private static final long FIVE_MINUTES_MS = 5L * 60L * 1000L;
    private static final long WEEK_MS = 7L * 24L * 60L * 60L * 1000L;

    private static int requestCode(String alarmId) {
        return 18000 + (alarmId == null ? 0 : (alarmId.hashCode() & 0x3fffffff) % 12000);
    }

    private static PendingIntent alarmIntent(Context context, String alarmId, long eventAt, String title, boolean recurring) {
        Intent intent = new Intent(context, TimesheetReminderReceiver.class);
        intent.putExtra("alarm_id", alarmId);
        intent.putExtra("event_at", eventAt);
        intent.putExtra("title", title);
        intent.putExtra("recurring", recurring);
        return PendingIntent.getBroadcast(
                context,
                requestCode(alarmId),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    public static void schedule(Context context, String alarmId, long eventAt, String title, boolean recurring) {
        if (eventAt <= 0L) return;
        long triggerAt = eventAt - FIVE_MINUTES_MS;
        if (triggerAt <= System.currentTimeMillis()) return;
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pendingIntent = alarmIntent(context, alarmId, eventAt, title, recurring);
            alarmManager.cancel(pendingIntent);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                    } else {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                    }
                } catch (SecurityException ex) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
            }
        } catch (Exception ignored) {}
    }

    public static void cancel(Context context, String alarmId) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pendingIntent = alarmIntent(context, alarmId, 0L, "TimeSheet", false);
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        } catch (Exception ignored) {}
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            rescheduleRecurring(context, intent);
            return;
        }

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "TimeSheet reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("5-minute reminders for TimeSheet plans you enable");
            manager.createNotificationChannel(channel);
        }

        String title = intent.getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "TimeSheet";

        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                requestCode("open-" + title),
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText("این برنامه تا ۵ دقیقه دیگر شروع می‌شود")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("این برنامه تا ۵ دقیقه دیگر شروع می‌شود"))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(contentIntent);

        NotificationManagerCompat.from(context).notify(requestCode(intent.getStringExtra("alarm_id")), builder.build());
        rescheduleRecurring(context, intent);
    }

    private void rescheduleRecurring(Context context, Intent intent) {
        if (!intent.getBooleanExtra("recurring", false)) return;
        String alarmId = intent.getStringExtra("alarm_id");
        String title = intent.getStringExtra("title");
        long nextEventAt = intent.getLongExtra("event_at", 0L) + WEEK_MS;
        while (nextEventAt - FIVE_MINUTES_MS <= System.currentTimeMillis()) nextEventAt += WEEK_MS;
        schedule(context, alarmId, nextEventAt, title, true);
    }
}
