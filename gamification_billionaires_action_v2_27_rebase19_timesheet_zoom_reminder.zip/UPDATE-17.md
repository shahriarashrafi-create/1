# Update 17 — Day / Night Readability & Layout Safety

Version: 2.17.0

## What changed
- Reworked both Day and Night themes for stronger text/background contrast.
- Day mode now uses opaque light surfaces with dark primary text and clearer muted text.
- Night mode uses brighter copy and slightly stronger borders without increasing glare.
- HUD cards, mission deck, task list, statistics, achievements, settings, dialogs, bottom navigation, toast and reward states now have explicit theme-specific colors.
- Android status/navigation bar icon appearance continues to follow the selected theme.
- Added collision-safe responsive rules to stop labels, icons, badges and buttons from drawing over one another.
- Added width/height fallbacks for compact phones and short screens.
- Long mission names can wrap safely to two lines; constrained labels use ellipsis rather than overlapping adjacent elements.
- Settings controls, focus sound controls, task rows and achievement cards were tightened for small screens.

## Compatibility
- Existing saves, tasks, stats, achievements, backups, audio settings and active focus sessions are preserved when updating from v2.16.
