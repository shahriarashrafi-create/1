# Update 24 — Campfire Combo + Fast Deck

- Combo thresholds remain 2 / 5 / 8 / 12 actions.
- Combo duration remains 30 minutes and the 2-minute Android reminder is retained.
- Campfire now displays 2, 3, 4, or 5 logs based on combo multiplier.
- Higher tiers have stronger, faster flame animation.
- Mission card swipe transitions are shorter and lighter.
- Return-to-first-task control has a new neon arrow design.
- Focus strip reads `Focus` while idle and shows the countdown only while active.
