# Update 21 — Rebase19 HUD + Focus

- Done! replaces Level in the HUD and shows today completed actions.
- Rank / XP / Combo use English labels with larger typography.
- 25-minute timer uses English digits and larger type.
- Focus helper text removed; start and stop are icon-only.
- Based directly on the v2.19 branch plus compact settings/audio changes.
