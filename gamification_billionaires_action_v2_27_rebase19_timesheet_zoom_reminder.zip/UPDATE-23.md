# Update 23 — Combo 30 + Flame

- Combo thresholds changed to 2 / 5 / 8 / 12 actions for ×2 / ×3 / ×4 / ×5.
- Combo expiration changed from 60 minutes to 30 minutes and is refreshed after every completion.
- Combo timer is larger and uses English digits.
- Emoji fire on the mission combo timer was replaced with a CSS animated flame that grows more intense at each combo tier.
- Android reminder notification is scheduled 2 minutes before combo expiration with English text.
- Existing v2.22 data is migrated and any longer active combo window is capped to 30 minutes.
