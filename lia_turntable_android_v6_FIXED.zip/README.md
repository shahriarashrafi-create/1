# Lia Turntable v6

Fixed Android build. The previous version accidentally contained a leading backslash before the Java package declaration.

Features:
- 32 full-body rotation frames (11.25-degree spacing)
- one-finger horizontal rotation
- two-finger pinch zoom
- continuous cross-fade between neighboring frames
- immersive fullscreen viewer
- compatible with workflows that look for gradlew/settings.gradle and run assembleDebug
