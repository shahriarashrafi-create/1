package com.shahriar.gamification;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT_BACKUP = 4101;
    private static final int REQ_IMPORT_BACKUP = 4102;
    private static final long DOUBLE_BACK_WINDOW_MS = 1800L;

    private WebView webView;
    private FrameLayout rootView;
    private String pendingBackupJson;
    private long lastBackPressAt = 0L;
    private boolean backCheckInFlight = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5103);
        }

        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        applySystemTheme(false);

        rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Color.rgb(7, 17, 30));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 17, 30));
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        rootView.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(rootView);

        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        if (savedInstanceState == null) {
            webView.clearCache(true);
            webView.clearHistory();
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void applySystemTheme(boolean light) {
        WindowInsetsControllerCompat controller = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(light);
        controller.setAppearanceLightNavigationBars(light);
        if (webView != null) webView.setBackgroundColor(light ? Color.rgb(238, 245, 251) : Color.rgb(7, 17, 30));
        if (rootView != null) rootView.setBackgroundColor(light ? Color.rgb(238, 245, 251) : Color.rgb(7, 17, 30));
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            if (json == null || json.trim().isEmpty()) return;
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
                intent.putExtra(Intent.EXTRA_TITLE, "Billionaires_Action_Backup_" + stamp + ".json");
                startActivityForResult(intent, REQ_EXPORT_BACKUP);
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQ_IMPORT_BACKUP);
            });
        }

        @JavascriptInterface
        public void setLightMode(boolean light) {
            runOnUiThread(() -> applySystemTheme(light));
        }

        @JavascriptInterface
        public void startFocusAudio(String mode, int volume, long endAt) {
            runOnUiThread(() -> {
                Intent intent = new Intent(MainActivity.this, FocusAudioService.class);
                intent.setAction(FocusAudioService.ACTION_START);
                intent.putExtra(FocusAudioService.EXTRA_MODE, mode == null ? "flow" : mode);
                intent.putExtra(FocusAudioService.EXTRA_VOLUME, Math.max(0, Math.min(100, volume)));
                intent.putExtra(FocusAudioService.EXTRA_END_AT, endAt);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent);
                    } else {
                        startService(intent);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void scheduleComboReminder(long expiresAt) {
            runOnUiThread(() -> {
                long triggerAt = expiresAt - 120_000L;
                if (triggerAt <= System.currentTimeMillis()) return;
                try {
                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    Intent intent = new Intent(MainActivity.this, ComboReminderReceiver.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            MainActivity.this,
                            ComboReminderReceiver.REQUEST_CODE,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );
                    alarmManager.cancel(pendingIntent);
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void cancelComboReminder() {
            runOnUiThread(() -> {
                try {
                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    Intent intent = new Intent(MainActivity.this, ComboReminderReceiver.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            MainActivity.this,
                            ComboReminderReceiver.REQUEST_CODE,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );
                    alarmManager.cancel(pendingIntent);
                    pendingIntent.cancel();
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void stopFocusAudio() {
            runOnUiThread(() -> {
                try { stopService(new Intent(MainActivity.this, FocusAudioService.class)); } catch (Exception ignored) {}
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT_BACKUP) {
            boolean ok = false;
            String fileName = "";
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        ok = true;
                        fileName = uri.getLastPathSegment() == null ? "backup.json" : uri.getLastPathSegment();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "ذخیره بکاپ انجام نشد", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
            final boolean result = ok;
            final String name = fileName;
            if (webView != null) webView.post(() -> webView.evaluateJavascript(
                    "typeof backupExportFinished==='function' ? backupExportFinished(" + result + "," + JSONObject.quote(name) + ") : false",
                    null
            ));
            return;
        }

        if (requestCode == REQ_IMPORT_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try (InputStream in = getContentResolver().openInputStream(uri);
                     BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                    String raw = sb.toString();
                    if (webView != null) webView.post(() -> webView.evaluateJavascript(
                            "typeof receiveBackupFromAndroid==='function' ? receiveBackupFromAndroid(" + JSONObject.quote(raw) + ") : false",
                            null
                    ));
                } catch (Exception e) {
                    Toast.makeText(this, "فایل بکاپ خوانده نشد", Toast.LENGTH_SHORT).show();
                    if (webView != null) webView.post(() -> webView.evaluateJavascript(
                            "typeof backupImportCancelled==='function' ? backupImportCancelled() : false",
                            null
                    ));
                }
            } else if (webView != null) {
                webView.post(() -> webView.evaluateJavascript(
                        "typeof backupImportCancelled==='function' ? backupImportCancelled() : false",
                        null
                ));
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "typeof resumeFromBackground==='function' ? resumeFromBackground() : false",
                    null
            ));
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "typeof prepareForBackground==='function' ? prepareForBackground() : true",
                    null
            );
        }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView == null || backCheckInFlight) return;
        backCheckInFlight = true;

        webView.evaluateJavascript(
                "(function(){var p=document.querySelector('.page.active');return p?p.id:'home';})()",
                value -> {
                    backCheckInFlight = false;
                    String page = value == null ? "home" : value.replace("\"", "").trim();

                    if (!"home".equals(page)) {
                        lastBackPressAt = 0L;
                        webView.evaluateJavascript(
                                "typeof goToPage==='function' ? goToPage('home') : 'home'",
                                null
                        );
                        return;
                    }

                    long now = SystemClock.elapsedRealtime();
                    if (now - lastBackPressAt <= DOUBLE_BACK_WINDOW_MS) {
                        lastBackPressAt = 0L;
                        webView.evaluateJavascript(
                                "typeof prepareForBackground==='function' ? prepareForBackground() : true",
                                null
                        );
                        moveTaskToBack(true);
                    } else {
                        lastBackPressAt = now;
                        Toast.makeText(this, "برای خروج دوباره دکمه برگشت را بزن", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
}
