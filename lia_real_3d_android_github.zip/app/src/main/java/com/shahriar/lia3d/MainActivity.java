package com.shahriar.lia3d;
import android.app.Activity;import android.os.Bundle;import android.view.View;import android.webkit.WebSettings;import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);WebView w=new WebView(this);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setAllowFileAccess(true);s.setDomStorageEnabled(true);s.setBuiltInZoomControls(false);w.setBackgroundColor(0x00000000);setContentView(w);w.loadUrl("file:///android_asset/index.html");}
}
