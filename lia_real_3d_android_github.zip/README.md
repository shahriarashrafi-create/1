# Lia Real 3D Android

این نسخه Sprite نیست؛ یک مدل Polygon Mesh واقعی سه‌بعدی دارد.

- مدل استاندارد GLB: `app/src/main/assets/model/lia_anime_3d.glb`
- مدل OBJ: `app/src/main/assets/model/lia_anime_3d.obj`
- نمایش Real-time WebGL داخل اپ
- یک انگشت: چرخش آزاد 360 درجه
- دو انگشت: Pinch Zoom
- Drag عمودی: Tilt محدود دوربین
- تمام‌صفحه و بدون وابستگی اینترنتی در زمان اجرا

GitHub Workflow قبلی که دنبال `gradlew` و `settings.gradle` می‌گردد، این پروژه را به عنوان پروژه Android تشخیص می‌دهد.
