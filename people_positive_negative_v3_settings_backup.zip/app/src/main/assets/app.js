(() => {
  const STORAGE_KEY = 'peopleScore.entries.v1';
  const LAST_PERSON_KEY = 'peopleScore.lastPerson.v1';
  let entries = loadEntries();
  let currentPage = 'home';
  let openedEntryId = null;
  let editType = 'positive';
  let toastTimer = null;

  const $ = (id) => document.getElementById(id);
  const homePage = $('homePage');
  const profilePage = $('profilePage');
  const personInput = $('personInput');
  const titleInput = $('titleInput');
  const descriptionInput = $('descriptionInput');
  const scoreInput = $('scoreInput');
  const detailModal = $('detailModal');
  const deleteModal = $('deleteModal');
  const settingsModal = $('settingsModal');
  const detailView = $('detailView');
  const editView = $('editView');

  function loadEntries() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(raw) ? raw.filter(Boolean) : [];
    } catch (_) { return []; }
  }

  function persist() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    renderPeopleSuggestions();
  }

  function uid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
  }

  function clampScore(value) {
    const n = Number.parseInt(value, 10);
    if (!Number.isFinite(n)) return 1;
    return Math.max(1, Math.min(999999, n));
  }

  function people() {
    const map = new Map();
    entries.forEach(e => {
      const name = String(e.person || '').trim();
      if (name && !map.has(name.toLocaleLowerCase('fa'))) map.set(name.toLocaleLowerCase('fa'), name);
    });
    return [...map.values()].sort((a,b) => a.localeCompare(b, 'fa'));
  }

  function renderPeopleSuggestions() {
    $('peopleSuggestions').innerHTML = people().map(name => `<option value="${escapeHtml(name)}"></option>`).join('');
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }

  function showToast(text) {
    const toast = $('toast');
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
  }

  function saveNewEntry(type) {
    const person = personInput.value.trim();
    const title = titleInput.value.trim();
    const description = descriptionInput.value.trim();
    const rawScore = scoreInput.value.trim();
    if (!person) { showToast('نام فرد را وارد کن'); personInput.focus(); return; }
    if (!title) { showToast('عنوان را وارد کن'); titleInput.focus(); return; }
    if (!rawScore || !Number.isFinite(Number(rawScore)) || Number(rawScore) < 1) { showToast('امتیاز را وارد کن'); scoreInput.focus(); return; }
    const score = clampScore(rawScore);

    entries.unshift({
      id: uid(),
      person,
      type: type === 'negative' ? 'negative' : 'positive',
      title,
      description,
      score,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    persist();
    localStorage.setItem(LAST_PERSON_KEY, person);
    titleInput.value = '';
    descriptionInput.value = '';
    scoreInput.value = '';
    showToast(type === 'negative' ? 'نکته منفی ثبت شد' : 'نکته مثبت ثبت شد');
  }

  function showPage(page, preferredPerson) {
    currentPage = page === 'profile' ? 'profile' : 'home';
    homePage.classList.toggle('active', currentPage === 'home');
    profilePage.classList.toggle('active', currentPage === 'profile');
    $('pageTitle').textContent = currentPage === 'home' ? 'ثبت ویژگی' : 'پروفایل';
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.page === currentPage));
    if (currentPage === 'profile') renderProfile(preferredPerson || personInput.value.trim());
    window.scrollTo({top:0, behavior:'auto'});
  }

  function renderProfile(preferredPerson) {
    const names = people();
    const select = $('profilePersonSelect');
    if (!names.length) {
      select.innerHTML = '<option value="">بدون فرد</option>';
      select.disabled = true;
      $('profileEmpty').classList.remove('hidden');
      $('profileContent').classList.add('hidden');
      return;
    }
    select.disabled = false;
    const previous = preferredPerson || select.value || localStorage.getItem(LAST_PERSON_KEY) || names[0];
    select.innerHTML = names.map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('');
    const chosen = names.includes(previous) ? previous : names[0];
    select.value = chosen;
    $('profileEmpty').classList.add('hidden');
    $('profileContent').classList.remove('hidden');
    renderPerson(chosen);
  }

  function renderPerson(person) {
    const personEntries = entries.filter(e => e.person === person);
    const positives = personEntries.filter(e => e.type === 'positive');
    const negatives = personEntries.filter(e => e.type === 'negative');
    const posTotal = positives.reduce((sum,e) => sum + clampScore(e.score), 0);
    const negTotal = negatives.reduce((sum,e) => sum + clampScore(e.score), 0);
    const net = posTotal - negTotal;

    $('selectedPersonName').textContent = person;
    $('positiveCount').textContent = positives.length;
    $('negativeCount').textContent = negatives.length;
    $('positiveTotal').textContent = `+${posTotal}`;
    $('negativeTotal').textContent = `−${negTotal}`;
    $('netScore').textContent = `${net > 0 ? '+' : net < 0 ? '−' : ''}${Math.abs(net)}`;
    $('netPill').className = `net-pill ${net > 0 ? 'positive' : net < 0 ? 'negative' : ''}`;

    renderColumn($('positiveList'), positives, '+');
    renderColumn($('negativeList'), negatives, '−');
    localStorage.setItem(LAST_PERSON_KEY, person);
  }

  function renderColumn(container, list, sign) {
    if (!list.length) {
      container.innerHTML = '<div class="empty-row">موردی ثبت نشده</div>';
      return;
    }
    container.innerHTML = list.map(e => `
      <button type="button" class="entry-row" data-entry-id="${escapeHtml(e.id)}">
        <span class="row-title">${escapeHtml(e.title)}</span>
        <span class="row-score">${sign}${clampScore(e.score)}</span>
      </button>`).join('');
  }

  function formatDate(iso) {
    try {
      return new Intl.DateTimeFormat('fa-IR', {dateStyle:'medium', timeStyle:'short'}).format(new Date(iso));
    } catch (_) { return ''; }
  }

  function openEntry(id) {
    const entry = entries.find(e => e.id === id);
    if (!entry) return;
    openedEntryId = id;
    $('detailKind').textContent = entry.type === 'positive' ? 'نکته مثبت' : 'نکته منفی';
    $('detailKind').style.color = entry.type === 'positive' ? 'var(--positive)' : 'var(--negative)';
    $('detailPerson').textContent = entry.person;
    $('detailTitle').textContent = entry.title;
    $('detailScore').textContent = `${entry.type === 'positive' ? '+' : '−'}${clampScore(entry.score)}`;
    $('detailScore').style.color = entry.type === 'positive' ? 'var(--positive)' : 'var(--negative)';
    $('detailDescription').textContent = entry.description || 'توضیحی ثبت نشده است.';
    $('detailDate').textContent = formatDate(entry.createdAt);
    detailView.classList.remove('hidden');
    editView.classList.add('hidden');
    detailModal.classList.remove('hidden');
    detailModal.setAttribute('aria-hidden','false');
  }

  function closeDetail() {
    detailModal.classList.add('hidden');
    detailModal.setAttribute('aria-hidden','true');
    openedEntryId = null;
  }

  function beginEdit() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) return;
    editType = entry.type;
    $('editTitle').value = entry.title;
    $('editScore').value = clampScore(entry.score);
    $('editDescription').value = entry.description || '';
    syncEditTypeButtons();
    detailView.classList.add('hidden');
    editView.classList.remove('hidden');
  }

  function syncEditTypeButtons() {
    document.querySelectorAll('[data-edit-type]').forEach(btn => btn.classList.toggle('active', btn.dataset.editType === editType));
  }

  function saveEdit() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) return;
    const title = $('editTitle').value.trim();
    if (!title) { showToast('عنوان را وارد کن'); return; }
    entry.title = title;
    entry.score = clampScore($('editScore').value);
    entry.description = $('editDescription').value.trim();
    entry.type = editType;
    entry.updatedAt = new Date().toISOString();
    persist();
    closeDetail();
    renderProfile(entry.person);
    showToast('تغییرات ذخیره شد');
  }

  function askDelete() {
    if (!openedEntryId) return;
    deleteModal.classList.remove('hidden');
    deleteModal.setAttribute('aria-hidden','false');
  }

  function closeDelete() {
    deleteModal.classList.add('hidden');
    deleteModal.setAttribute('aria-hidden','true');
  }

  function confirmDelete() {
    const entry = entries.find(e => e.id === openedEntryId);
    if (!entry) { closeDelete(); return; }
    const person = entry.person;
    entries = entries.filter(e => e.id !== openedEntryId);
    persist();
    closeDelete();
    closeDetail();
    renderProfile(person);
    showToast('مورد حذف شد');
  }

  function openSettings() {
    settingsModal.classList.remove('hidden');
    settingsModal.setAttribute('aria-hidden','false');
  }

  function closeSettings() {
    settingsModal.classList.add('hidden');
    settingsModal.setAttribute('aria-hidden','true');
  }

  function backupPayload() {
    return {
      app: 'People Score',
      version: 1,
      exportedAt: new Date().toISOString(),
      entries: entries,
      lastPerson: localStorage.getItem(LAST_PERSON_KEY) || ''
    };
  }

  function fallbackExport(jsonText) {
    try {
      const blob = new Blob([jsonText], {type:'application/json;charset=utf-8'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const day = new Date().toISOString().slice(0,10);
      a.href = url;
      a.download = `people-score-backup-${day}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      showToast('فایل بکاپ آماده شد');
    } catch (_) { showToast('خروجی گرفتن انجام نشد'); }
  }

  function exportBackup() {
    const jsonText = JSON.stringify(backupPayload(), null, 2);
    if (window.AndroidBackup && typeof window.AndroidBackup.exportData === 'function') {
      window.AndroidBackup.exportData(jsonText);
    } else {
      fallbackExport(jsonText);
    }
  }

  function importBackup() {
    if (window.AndroidBackup && typeof window.AndroidBackup.importData === 'function') {
      window.AndroidBackup.importData();
    } else {
      showToast('Import فقط در اپ اندروید فعال است');
    }
  }

  window.receiveImportedBackup = (jsonText) => {
    try {
      const data = JSON.parse(jsonText);
      const imported = Array.isArray(data) ? data : data.entries;
      if (!Array.isArray(imported)) throw new Error('invalid');
      const cleaned = imported.filter(e => e && typeof e === 'object' && String(e.person || '').trim() && String(e.title || '').trim()).map(e => ({
        id: String(e.id || uid()),
        person: String(e.person || '').trim().slice(0,60),
        type: e.type === 'negative' ? 'negative' : 'positive',
        title: String(e.title || '').trim().slice(0,70),
        description: String(e.description || '').slice(0,700),
        score: clampScore(e.score),
        createdAt: e.createdAt || new Date().toISOString(),
        updatedAt: e.updatedAt || e.createdAt || new Date().toISOString()
      }));
      entries = cleaned;
      persist();
      const last = !Array.isArray(data) && data.lastPerson ? String(data.lastPerson).trim() : '';
      if (last) localStorage.setItem(LAST_PERSON_KEY, last);
      if (last) personInput.value = last;
      closeSettings();
      if (currentPage === 'profile') renderProfile(last);
      showToast(`${entries.length} مورد بازیابی شد`);
    } catch (_) {
      showToast('فایل بکاپ معتبر نیست');
    }
  };

  window.androidBackupResult = (message) => {
    if (message) showToast(String(message));
  };

  $('clearPerson').addEventListener('click', () => { personInput.value = ''; personInput.focus(); });
  $('settingsBtn').addEventListener('click', openSettings);
  document.querySelectorAll('[data-close="settings"]').forEach(el => el.addEventListener('click', closeSettings));
  $('exportBtn').addEventListener('click', exportBackup);
  $('importBtn').addEventListener('click', importBackup);
  $('savePositive').addEventListener('click', () => saveNewEntry('positive'));
  $('saveNegative').addEventListener('click', () => saveNewEntry('negative'));
  document.querySelectorAll('.nav-btn').forEach(btn => btn.addEventListener('click', () => showPage(btn.dataset.page)));
  $('emptyGoHome').addEventListener('click', () => showPage('home'));
  $('profilePersonSelect').addEventListener('change', e => renderPerson(e.target.value));
  $('profileContent').addEventListener('click', e => {
    const row = e.target.closest('[data-entry-id]');
    if (row) openEntry(row.dataset.entryId);
  });
  document.querySelectorAll('[data-close="detail"]').forEach(el => el.addEventListener('click', closeDetail));
  document.querySelectorAll('[data-close="delete"]').forEach(el => el.addEventListener('click', closeDelete));
  $('editEntryBtn').addEventListener('click', beginEdit);
  $('deleteEntryBtn').addEventListener('click', askDelete);
  $('saveEditBtn').addEventListener('click', saveEdit);
  $('cancelEditBtn').addEventListener('click', () => { detailView.classList.remove('hidden'); editView.classList.add('hidden'); });
  $('confirmDeleteBtn').addEventListener('click', confirmDelete);
  document.querySelectorAll('[data-edit-type]').forEach(btn => btn.addEventListener('click', () => { editType = btn.dataset.editType; syncEditTypeButtons(); }));

  window.handleAndroidBack = () => {
    if (!settingsModal.classList.contains('hidden')) { closeSettings(); return 'handled'; }
    if (!deleteModal.classList.contains('hidden')) { closeDelete(); return 'handled'; }
    if (!detailModal.classList.contains('hidden')) {
      if (!editView.classList.contains('hidden')) { detailView.classList.remove('hidden'); editView.classList.add('hidden'); return 'handled'; }
      closeDetail(); return 'handled';
    }
    if (currentPage === 'profile') { showPage('home'); return 'handled'; }
    return 'exit';
  };

  const lastPerson = localStorage.getItem(LAST_PERSON_KEY);
  if (lastPerson) personInput.value = lastPerson;
  renderPeopleSuggestions();
})();
