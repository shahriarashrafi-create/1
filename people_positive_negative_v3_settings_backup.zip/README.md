# PeopleScore — مثبت / منفی

اپلیکیشن اندروید آفلاین برای ثبت نکات مثبت و منفی افراد.

## نسخه 1.0
- صفحه ثبت: نام فرد، مثبت/منفی، عنوان، امتیاز 1 تا 100، توضیحات
- صفحه پروفایل: انتخاب فرد و نمایش دو ستون مثبت و منفی
- هر ردیف شامل عنوان و امتیاز است
- لمس هر ردیف: نمایش توضیحات، تاریخ، ویرایش و حذف
- مجموع امتیاز مثبت و منفی در پایین هر ستون
- امتیاز خالص در پروفایل
- ذخیره آفلاین روی گوشی با LocalStorage
- بدون صفحه جداگانه افراد و بدون صفحه جداگانه مثبت‌ها/منفی‌ها

## GitHub Actions
فایل `.github/workflows/build-apk.yml` با هر Push پروژه را Build می‌کند و APK را در Artifacts قرار می‌دهد.


## Version 3
- Added a settings gear next to the home title.
- Added Android Storage Access Framework export/import backup as JSON.
- Export includes all entries and last selected person; Import restores them.
