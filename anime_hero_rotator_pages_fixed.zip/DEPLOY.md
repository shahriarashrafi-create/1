# GitHub Pages deployment

This project is a static site.

## Important
Upload the CONTENTS of this package to the repository root so that these files are at the top level:

- `index.html`
- `app.js`
- `styles.css`
- `assets/`
- `.github/workflows/pages.yml`
- `.nojekyll`

The included workflow deploys automatically on pushes to `main`.

In GitHub:
1. Open **Settings → Pages**.
2. Under **Build and deployment**, set **Source** to **GitHub Actions**.
3. Push/commit the files to the `main` branch.
4. Open **Actions** and select `Deploy static site to GitHub Pages`.
