package com.shahriar.herorotator;

import android.app.Activity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private ImageView heroImage;
    private TextView viewLabel;
    private TextView counter;

    private final int[] images = {
        R.drawable.hero_front,
        R.drawable.hero_right,
        R.drawable.hero_back,
        R.drawable.hero_left
    };

    private final int[] labels = {
        R.string.front,
        R.string.right,
        R.string.back,
        R.string.left
    };

    private int currentIndex = 0;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        heroImage = findViewById(R.id.heroImage);
        viewLabel = findViewById(R.id.viewLabel);
        counter = findViewById(R.id.counter);

        Button leftButton = findViewById(R.id.leftButton);
        Button rightButton = findViewById(R.id.rightButton);
        View viewer = findViewById(R.id.viewer);

        leftButton.setOnClickListener(v -> rotateLeft());
        rightButton.setOnClickListener(v -> rotateRight());

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            private static final float SWIPE_THRESHOLD = 80f;
            private static final float SWIPE_VELOCITY_THRESHOLD = 80f;

            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;

                float diffX = e2.getX() - e1.getX();
                float diffY = e2.getY() - e1.getY();

                if (Math.abs(diffX) > Math.abs(diffY)
                        && Math.abs(diffX) > SWIPE_THRESHOLD
                        && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX < 0) {
                        rotateRight();
                    } else {
                        rotateLeft();
                    }
                    return true;
                }
                return false;
            }
        });

        viewer.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));
        render(false);
    }

    private void rotateRight() {
        currentIndex = (currentIndex + 1) % images.length;
        render(true);
    }

    private void rotateLeft() {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        render(true);
    }

    private void render(boolean animate) {
        if (!animate) {
            applyFrame();
            return;
        }

        heroImage.animate()
                .alpha(0f)
                .scaleX(0.97f)
                .scaleY(0.97f)
                .setDuration(110)
                .withEndAction(() -> {
                    applyFrame();
                    heroImage.animate()
                            .alpha(1f)
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(150)
                            .start();
                })
                .start();
    }

    private void applyFrame() {
        heroImage.setImageResource(images[currentIndex]);
        heroImage.setContentDescription(getString(labels[currentIndex]));
        viewLabel.setText(labels[currentIndex]);
        counter.setText((currentIndex + 1) + " / " + images.length);
    }
}
