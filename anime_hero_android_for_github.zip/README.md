# Anime Hero Rotator — Android

Native Android version of the hero rotation prototype.

## GitHub Actions compatibility

This ZIP is designed for the workflow that:
- extracts the newest ZIP
- searches for `gradlew` / `settings.gradle`
- runs `./gradlew clean assembleDebug`
- uploads the resulting `*-debug.apk`

## Features

- Native Android app
- 4-direction character rotation
- Left/right buttons
- Swipe gesture
- Animated frame transition
- Portrait layout
- Min Android version: Android 6.0 (API 23)

## APK output

After a successful build, the APK is normally created at:

`app/build/outputs/apk/debug/app-debug.apk`
