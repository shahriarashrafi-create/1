
const views = [
  { src: "assets/views/front.png", label: "روبه‌رو", alt: "نمای روبه‌رو کاراکتر" },
  { src: "assets/views/right.png", label: "راست", alt: "نمای سمت راست کاراکتر" },
  { src: "assets/views/back.png", label: "پشت", alt: "نمای پشت کاراکتر" },
  { src: "assets/views/left.png", label: "چپ", alt: "نمای سمت چپ کاراکتر" },
];

let index = 0;
let startX = null;

const image = document.getElementById("characterImage");
const viewName = document.getElementById("viewName");
const viewIndex = document.getElementById("viewIndex");
const viewer = document.getElementById("viewer");
const dots = document.getElementById("dots");

views.forEach((_, i) => {
  const dot = document.createElement("button");
  dot.className = "dot";
  dot.type = "button";
  dot.setAttribute("aria-label", `زاویه ${i + 1}`);
  dot.addEventListener("click", () => setView(i));
  dots.appendChild(dot);
});

function render() {
  const view = views[index];
  image.classList.add("switching");

  window.setTimeout(() => {
    image.src = view.src;
    image.alt = view.alt;
    viewName.textContent = view.label;
    viewIndex.textContent = `${index + 1} / ${views.length}`;

    [...dots.children].forEach((dot, i) => {
      dot.classList.toggle("active", i === index);
    });

    requestAnimationFrame(() => image.classList.remove("switching"));
  }, 120);
}

function setView(next) {
  index = (next + views.length) % views.length;
  render();
}

function rotateRight() { setView(index + 1); }
function rotateLeft() { setView(index - 1); }

document.getElementById("rotateRight").addEventListener("click", rotateRight);
document.getElementById("rotateLeft").addEventListener("click", rotateLeft);
document.getElementById("nextBtn").addEventListener("click", rotateRight);
document.getElementById("prevBtn").addEventListener("click", rotateLeft);

viewer.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight") rotateRight();
  if (e.key === "ArrowLeft") rotateLeft();
});

viewer.addEventListener("pointerdown", (e) => {
  startX = e.clientX;
});

viewer.addEventListener("pointerup", (e) => {
  if (startX === null) return;
  const dx = e.clientX - startX;
  if (Math.abs(dx) > 35) {
    dx < 0 ? rotateRight() : rotateLeft();
  }
  startX = null;
});

render();
