# Anime Hero Rotator

یک وب‌اپ سبک و GitHub-ready برای نمایش کاراکتر انیمه با چرخش چهارجهته.

## امکانات

- چرخش چپ و راست
- چهار زاویه: روبه‌رو، راست، پشت، چپ
- کنترل با دکمه‌ها
- کنترل با کلیدهای Arrow
- Swipe روی موبایل
- طراحی Responsive
- بدون نیاز به Build Tool

## اجرا

فایل `index.html` را مستقیم در مرورگر باز کنید.

یا با Python:

```bash
python -m http.server 8080
```

بعد بروید به:

```text
http://localhost:8080
```

## انتشار روی GitHub Pages

1. فایل‌ها را داخل یک Repository قرار دهید.
2. وارد Settings > Pages شوید.
3. Branch اصلی را برای Deploy انتخاب کنید.
4. چند لحظه بعد سایت روی GitHub Pages در دسترس است.

## جایگزین کردن کاراکتر

تصاویر این مسیر را با رندرهای نهایی خودت جایگزین کن:

```text
assets/views/front.png
assets/views/right.png
assets/views/back.png
assets/views/left.png
```

بهتر است همه تصاویر:
- پس‌زمینه یکسان داشته باشند
- ابعاد یکسان داشته باشند
- مرکز بدن در همه فریم‌ها ثابت باشد

## ساختار

```text
anime_hero_rotator_app/
├── index.html
├── styles.css
├── app.js
├── README.md
└── assets/
    ├── character-sheet.jpg
    └── views/
        ├── front.png
        ├── right.png
        ├── back.png
        └── left.png
```

## نکته

تصاویر فعلی از کانسپت اولیه استخراج شده‌اند و فقط برای پروتوتایپ هستند. برای نتیجه‌ی حرفه‌ای در بازی، بهتر است چهار رندر تمیز با زاویه‌ی دقیق 0° / 90° / 180° / 270° جایگزین شوند.
