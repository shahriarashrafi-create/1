# Update 29 — Rewards Hub + Derakhtvare v21

Base: Gamification v2.28 + Derakhtvare v21.

## Rewards Hub
- صندوق and دستاوردها are now one page named «پاداش‌ها».
- Added a compact internal switch for صندوق / دستاوردها.
- Existing chest progress, chest rewards, achievement filters, custom achievements, claiming, and notification dots are preserved.
- Redesigned the page with a unified gold / blue / violet reward theme.

## Derakhtvare
- Added a new bottom-navigation page titled «درختواره».
- Integrated Derakhtvare v21 as an in-app surface and restyled it to match Gamification.
- Four top modes: PV / GPV, درختواره, مقایسه, رنکینگ.
- PV / GPV cards allow person-by-person PV, GPV, and active-person entry.
- Circular hierarchy supports add/edit member, expand/collapse, and zoom down to 20% as in v21.
- Comparison includes person comparison and archived date comparison.
- Ranking includes PV, GPV, organization members, and network actions.
- Parent dark/light theme is synchronized into the tree UI.
- Tree data is mirrored into the Gamification backup envelope.
