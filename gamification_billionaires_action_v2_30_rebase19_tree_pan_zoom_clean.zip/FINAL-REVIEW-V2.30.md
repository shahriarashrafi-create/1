# Final Review — v2.30

- Version name: 2.30.0
- Version code: 41
- Base: v2.29 / v19 rebase lineage
- Gamification Tree Hub top title/subtitle/version strip: removed
- Embedded Tree page title/header strip: hidden from UI
- Four mode selectors (PV/GPV / Tree / Compare / Ranking): preserved
- Expand-all: icon-only
- Collapse-all: icon-only
- Direct zoom buttons: preserved
- Pinch zoom: 20%–180%
- One-finger free pan: horizontal + vertical
- Drag click suppression: enabled
- Initial/reset/collapse centering: enabled
- JavaScript syntax: PASS
- Mobile touch interaction smoke test: PASS
- Duplicate static HTML IDs: none
