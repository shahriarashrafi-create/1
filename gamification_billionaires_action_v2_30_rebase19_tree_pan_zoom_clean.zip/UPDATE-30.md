# Update 30 — Tree Navigation Polish

Base: v2.29 on the v19 rebase branch.

- Removed the visible Gamification Tree Hub header, subtitle and v21 badge.
- Hid the embedded Tree application page-title/header strip.
- Kept PV/GPV, Tree, Compare and Ranking mode buttons as the main selector.
- Replaced «بازکردن همه» / «بستن همه» text buttons with two icon-only actions.
- Kept direct zoom controls and pinch zoom.
- Added one-finger drag/pan navigation in the expanded circular tree, in both horizontal and vertical directions.
- Dragging suppresses accidental person-card clicks.
- Added automatic centering after reset/collapse and initial Tree entry.
