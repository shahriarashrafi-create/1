\
package com.shahriar.animeturntable;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.LruCache;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

public class SpriteTurntableView extends View {
    private static final int FRAME_COUNT = 24;
    private static final float DEGREES_PER_FRAME = 360f / FRAME_COUNT;

    private final int[] frameIds = new int[FRAME_COUNT];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final ScaleGestureDetector scaleDetector;
    private final LruCache<Integer, Bitmap> bitmapCache;

    private float angleDeg = 0f;
    private float zoom = 1f;
    private float downX = 0f;
    private float baseFitScale = 1f;

    public SpriteTurntableView(Context context) {
        this(context, null);
    }

    public SpriteTurntableView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.parseColor("#100D14"));
        setLayerType(View.LAYER_TYPE_HARDWARE, null);

        for (int i = 0; i < FRAME_COUNT; i++) {
            frameIds[i] = getResources().getIdentifier(
                    String.format("frame_%02d", i),
                    "drawable",
                    context.getPackageName()
            );
        }

        // Keep only a few decoded frames in memory for smooth rotation without OOM.
        final int cacheKb = 24 * 1024;
        bitmapCache = new LruCache<Integer, Bitmap>(cacheKb) {
            @Override
            protected int sizeOf(Integer key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };

        scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector detector) {
                        zoom *= detector.getScaleFactor();
                        zoom = Math.max(0.85f, Math.min(4.0f, zoom));
                        invalidate();
                        return true;
                    }
                });
    }

    private Bitmap getFrame(int index) {
        index = (index % FRAME_COUNT + FRAME_COUNT) % FRAME_COUNT;
        Bitmap cached = bitmapCache.get(index);
        if (cached != null && !cached.isRecycled()) return cached;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), frameIds[index], opts);
        if (bmp != null) bitmapCache.put(index, bmp);
        return bmp;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Bitmap first = getFrame(0);
        if (first != null) {
            float fitX = (float) w / first.getWidth();
            float fitY = (float) h / first.getHeight();
            // Fill most of screen while keeping whole character visible.
            baseFitScale = Math.min(fitX, fitY) * 1.04f;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.parseColor("#100D14"));

        float normalized = normalizeAngle(angleDeg);
        float exactFrame = normalized / DEGREES_PER_FRAME;
        int lower = (int) Math.floor(exactFrame) % FRAME_COUNT;
        int upper = (lower + 1) % FRAME_COUNT;
        float mix = exactFrame - (float) Math.floor(exactFrame);

        Bitmap a = getFrame(lower);
        Bitmap b = getFrame(upper);
        if (a == null) return;

        drawFrame(canvas, a, 1f - mix);
        if (b != null && mix > 0.001f) {
            drawFrame(canvas, b, mix);
        }
    }

    private void drawFrame(Canvas canvas, Bitmap bmp, float alpha) {
        float s = baseFitScale * zoom;
        float bw = bmp.getWidth() * s;
        float bh = bmp.getHeight() * s;

        Matrix m = new Matrix();
        m.postScale(s, s);
        m.postTranslate((getWidth() - bw) / 2f, (getHeight() - bh) / 2f);

        paint.setAlpha(Math.max(0, Math.min(255, (int) (255f * alpha))));
        canvas.drawBitmap(bmp, m, paint);
        paint.setAlpha(255);
    }

    private float normalizeAngle(float value) {
        float a = value % 360f;
        return a < 0f ? a + 360f : a;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!scaleDetector.isInProgress() && event.getPointerCount() == 1) {
                    float x = event.getX();
                    float dx = x - downX;
                    // ~180° across screen width; smooth enough for precise control.
                    float sensitivity = 180f / Math.max(1f, getWidth());
                    angleDeg += dx * sensitivity;
                    downX = x;
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                int remainingIndex = event.getActionIndex() == 0 ? 1 : 0;
                if (remainingIndex < event.getPointerCount()) {
                    downX = event.getX(remainingIndex);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                performClick();
                return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }
}
