# Lia Turntable Android v5

Fullscreen anime turntable for Android.

## Gestures
- One finger horizontal drag: 360° rotation
- Two fingers pinch: zoom 0.85x–4x

## Rotation quality
- 24 rendered source views (15° spacing)
- Intermediate angles are cross-faded continuously, so dragging can stop at any degree
- Full-screen immersive presentation
- Small bitmap cache keeps memory usage controlled

## GitHub workflow compatibility
This ZIP contains `gradlew`, `settings.gradle`, and a native Android Gradle project, so the existing APK workflow can detect and build it.
